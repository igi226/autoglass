<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="socket.io" data-server="<?php echo e(env('WEBSOCKET_SERVER')); ?>" data-protocol-number="<?php echo e(get_user_details()->id); ?>" data-note-route="<?php echo e(route('vendor.notifications')); ?>" data-pk="<?php echo e(env('WEBSOCKET_PUBLIC_KEY')); ?>">
    <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport"> <!-- Title -->
    <title><?php echo e(env('APP_NAME')); ?> - <?php echo $__env->yieldContent('title'); ?></title> <!-- Font Awesome -->
    <link href="<?php echo e(asset('vendors')); ?>/assets/plugins/fontawesome-free/css/all.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="<?php echo e(asset('vendors')); ?>/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Ionicons -->
    <link href="<?php echo e(asset('vendors')); ?>/assets/plugins/ionicons/css/ionicons.min.css" rel="stylesheet">
    <!-- Typicons -->
    <link href="<?php echo e(asset('vendors')); ?>/assets/plugins/typicons.font/typicons.css" rel="stylesheet">
    <!-- Sidebar css -->
    <link href="<?php echo e(asset('vendors')); ?>/assets/plugins/select2/css/select2.min.css" rel="stylesheet">
    <!-- morris css -->
    <link rel="stylesheet" href="<?php echo e(asset('vendors')); ?>/assets/plugins/toast/css/toast.min.css">
    <!--Bootstrap-daterangepicker css-->
    <!-- Default Style -->
    <link href="<?php echo e(asset('vendors')); ?>/assets/css/style.css" rel="stylesheet"> <!-- Skins Css -->
    <link href="<?php echo e(asset('vendors')); ?>/assets/css/skins.css" rel="stylesheet"> <!-- Icon Style -->
    <link href="<?php echo e(asset('vendors')); ?>/assets/css/icons.css" rel="stylesheet">
</head>

<body class="main-body sidebar-gone">
    <?php echo $__env->make('components.vendor.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>


    <?php echo $__env->make('components.vendor.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.vendor.report', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('vendors')); ?>/assets/plugins/jquery/jquery.min.js"></script>
    <script src="<?php echo e(asset('vendors')); ?>/assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('vendors')); ?>/assets/plugins/ionicons/ionicons.js"></script>
    <script src="<?php echo e(asset('vendors')); ?>/assets/plugins/toast/js/jquery.toast.js"></script>
    <script src="<?php echo e(asset('common')); ?>/socket.io.min.js"></script>
    <script src="<?php echo e(asset('vendors')); ?>/assets/js/sticky.js"></script>
    <script src="<?php echo e(asset('vendors')); ?>/assets/js/notification.js"></script>
    <script src="<?php echo e(asset('vendors')); ?>/assets/js/custom.js"></script>
    <script src="<?php echo e(asset('vendors')); ?>/assets/js/html2canvas.min.js"></script>
    <script src="<?php echo e(asset('vendors')); ?>/assets/js/report.js"></script>
    <script>
        <?php if(Session::has('success')): ?>
            $.toast({
                heading: 'Success!',
                text: '<?php echo e(Session::get('success')); ?>',
                icon: "success",
                hideAfter: 3000,
                allowToastClose:false
            })
        <?php elseif(Session::has('error')): ?>
            $.toast({
                heading: 'Error',
                text: '<?php echo e(Session::get('error')); ?>',
                icon: "danger",
                hideAfter: 3000,
                allowToastClose:false
            })
        <?php endif; ?>
    </script>
    <?php echo $__env->yieldContent('script'); ?>
    <div class="main-navbar-backdrop"></div>
</body>

</html>
<?php /**PATH C:\Users\MORNING\Desktop\GlassInventory\resources\views/vendor/layouts/app.blade.php ENDPATH**/ ?>