

<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admins')); ?>/assets/modules/summernote/summernote-bs4.css">
    <link rel="stylesheet" href="<?php echo e(asset('admins')); ?>/assets/modules/jquery-selectric/selectric.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content" style="min-height: 702px;">
        <section class="section">
            <div class="section-header">
                <h1>Edit User</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="#">Admin</a></div>
                    <div class="breadcrumb-item"><a href="#">User Management</a></div>
                    <div class="breadcrumb-item">Edit User</div>
                </div>
            </div>

            <div class="section-body">
                <div class="row">
                    <div class="col-12">
                        <form class="card needs-validation" method="POST" action="<?php echo e(route('admin.user.update', ['id' => $user->id])); ?>"
                            novalidate>
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <div class="form-group row mb-4">
                                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">
                                        Name <small class="text-danger">*</small>
                                    </label>
                                    <div class="col-sm-12 col-md-7">
                                        <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control" required>
                                        <div class="invalid-feedback">Name is Required</div>
                                    </div>
                                </div>
                                <div class="form-group row mb-4">
                                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">
                                        Email <small class="text-danger">*</small>
                                    </label>
                                    <div class="col-sm-12 col-md-7">
                                        <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control" required>
                                        <div class="invalid-feedback">Email is Required</div>
                                    </div>
                                </div>
                                <div class="form-group row mb-4">
                                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">
                                        Mobile No.
                                    </label>
                                    <div class="col-sm-12 col-md-7">
                                        <input type="tel" name="phone" value="<?php echo e($user->phone); ?>" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group row mb-4">
                                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">
                                        Address
                                    </label>
                                    <div class="col-sm-12 col-md-7">
                                        <textarea type="text" name="address" class="form-control" rows="4"><?php echo e($user->address); ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row mb-4">
                                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">
                                        Company
                                    </label>
                                    <div class="col-sm-12 col-md-7">
                                        <input type="text" name="company" class="form-control" value="<?php echo e($user->company); ?>">
                                    </div>
                                </div>
                                <div class="form-group row mb-4">
                                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">
                                        Owner
                                    </label>
                                    <div class="col-sm-12 col-md-7">
                                        <input type="text" name="owner" class="form-control" value="<?php echo e($user->owner); ?>">
                                    </div>
                                </div>
                                <div class="form-group row mb-4">
                                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">
                                        Tax Id
                                    </label>
                                    <div class="col-sm-12 col-md-7">
                                        <input type="text" name="tax_id" class="form-control" value="<?php echo e($user->tax_id); ?>">
                                    </div>
                                </div>
                                <div class="form-group row mb-4">
                                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">User
                                        Category</label>
                                    <div class="col-sm-12 col-md-7">
                                        <select class="form-control selectric" name="type" tabindex="-1">
                                            <option value="0" <?php if($user->type == 0): ?> selected <?php endif; ?>>General Consumer</option>
                                            <option value="1"  <?php if($user->type == 1): ?> selected <?php endif; ?>>Vendor/Buyer</option>
                                            <option value="2"  <?php if($user->type == 2): ?> selected <?php endif; ?>>Administrator</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row mb-4">
                                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                                    <div class="col-sm-12 col-md-7">
                                        <button class="btn btn-primary">Save Changes</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('admins')); ?>/assets/modules/jquery-selectric/jquery.selectric.min.js"></script>
    <script>
        $('#generate').on('click', function() {
            let password = (Math.random() + 1).toString(36).substring(2);

            $('#password').val(password)
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/autoglassb2b/public_html/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>