

<?php $__env->startSection('title', 'Product Inventory'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="main-content-body d-flex flex-column">
                        <!-- breadcrumb -->
                        <div class="main-content-breadcrumb"> <span>Vendor</span> <span>Products</span>
                            <span>Product Inventory</span>
                            <div class="main-content-title mb-0 ml-auto">Product Inventory</div>
                        </div> <!-- /breadcrumb -->

                        <div class="card">
                            <div class="card-body">
                                <div class="main-content-label mg-b-5">Products</div>
                                <p class="mg-b-20">Here is all Available Product. You can Import and Customize Price</p>
                                <div class="col-6 float-left p-0 mb-3">
                                    <button class="btn btn-primary" type="button" id="btn-import">
                                        <i class="fas fa-file-import"></i>
                                        Import
                                    </button>
                                    <button class="btn btn-info ms-3" type="button" data-target="#importModal"
                                        data-toggle="modal">
                                        <i class="fas fa-upload"></i>
                                        Upload Excel
                                    </button>
                                </div>
                                <form method="GET" class="col-md-4 col-6 mb-3 p-0 float-right">
                                    <div class="input-group">
                                        <input class="form-control" name="search" placeholder="Search" type="text">
                                        <span class="input-group-btn">
                                            <button class="btn btn-primary" type="submit">
                                                <span class="input-group-btn">
                                                    <i class="fa fa-search"></i>
                                                </span>
                                            </button>
                                        </span>
                                    </div>
                                </form>
                                <div class="table-responsive">
                                    <table id="example-1" class="table table-striped table-bordered nowrap text-md-nowrap">
                                        <thead>
                                            <tr>
                                                <th class="border-bottom-0">
                                                    <input type="checkbox" name="" id="check-all">
                                                </th>
                                                <th class="border-bottom-0">Year</th>
                                                <th class="border-bottom-0">Make</th>
                                                <th class="border-bottom-0">Model</th>
                                                <th class="border-bottom-0">Type</th>
                                                <th class="border-bottom-0">Part Number</th>
                                                <th class="border-bottom-0">Brand</th>
                                                <th class="border-bottom-0">Description</th>
                                                <th class="border-bottom-0">Part Description</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="border-bottom-0">
                                                        <input type="checkbox" value="<?php echo e($product->id); ?>" name=""
                                                            class="product-checked">
                                                    </td>
                                                    <td><?php echo e($product->year); ?></td>
                                                    <td><?php echo e($product->make); ?></td>
                                                    <td><?php echo e($product->model); ?></td>
                                                    <td><?php echo e($product->type); ?></td>
                                                    <td><?php echo e($product->part_number); ?></td>
                                                    <td><?php echo e($product->brand); ?></td>
                                                    <td><?php echo e($product->description); ?></td>
                                                    <td><?php echo e($product->part_description); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php echo $__env->make('components.admin.pagination', ['paginator' => $products], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <!--/div-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('components.vendor.import', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if($products->count() == 0): ?>
        <?php echo $__env->make('components.vendor.single', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script id="script" data-src="<?php echo e(route('vendor.product.import')); ?>" data-csrf="<?php echo e(csrf_token()); ?>"></script>
    <script src="<?php echo e(asset('vendors')); ?>/assets/js/product.js"></script>
    <?php if($products->count() == 0): ?>
       <script>
            $('#singleModal').modal('show');
       </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/q7pqffo8kaqr/public_html/autoglassb2b.com/resources/views/vendor/products/index.blade.php ENDPATH**/ ?>