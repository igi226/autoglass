

<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content main-content-mail">
        <div class="container">
            <div class="row row-sm">
                <div class="col-md-8 mx-auto">
                    <div class="card">
                        <div class="main-content-body main-content-body-mail card-body">
                            <div class="main-mail-list">
                                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="main-mail-item unread selected" data-redirect-to="<?php echo e($notification->url); ?>">
                                        <div class="main-img-user"><img alt=""
                                                src="<?php echo e(asset('vendors')); ?>/assets/img/users/user.png"></div>
                                        <div class="main-mail-body">
                                            <?php echo $notification->message; ?>

                                        </div>
                                        <div class="main-mail-date"><?php echo e($notification->created_at->format('d F, H:i')); ?></div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php echo $__env->make('components.admin.pagination', ['paginator' => $notifications], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div> <!-- Col-->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MORNING\Desktop\GlassInventory\resources\views/vendor/notifications.blade.php ENDPATH**/ ?>