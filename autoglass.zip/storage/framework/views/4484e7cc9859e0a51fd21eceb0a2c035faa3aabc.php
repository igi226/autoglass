<h1>Password Reset Mail</h1>

  

Please verify your email to rest password with bellow link: 

<a href="<?php echo e(route('vendor.reset-password', $token)); ?>">Password Reset</a><?php /**PATH /home/autoglassb2b/public_html/resources/views/vendor/emails/passwordReset.blade.php ENDPATH**/ ?>