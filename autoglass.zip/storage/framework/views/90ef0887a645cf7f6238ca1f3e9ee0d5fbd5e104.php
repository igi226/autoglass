

<?php $__env->startSection('title', 'My Purchase'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="main-content-breadcrumb"> <span>Vendor</span><span>My Purchase</span>
                        <div class="main-content-title ml-auto mb-0">My Purchase</div>
                    </div>
                    <div class="main-content-header container p-4 bg-white">
                        <div>
                            <h6 class="main-content-title tx-18 mg-b-5 mg-t-5">My Purchase</h6>
                            <p class="main-content-text tx-13 mg-b-5">This is a Dedicated page for your Purchase history. You
                                can Details or Confirm their payment from here</p>
                        </div>
                    </div>
                    <div class="main-content-body d-flex flex-column">
                        <div class="row row-sm row-cards row-deck">
                            <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-6 req-card">
                                    <div class="card mg-b-20 card-aside">
                                        <div class="card-body d-flex flex-column">
                                            <span class="badge badge-danger ribbon">Paid</span>
                                            <h4>
                                                <a href="#" class="text-dark tx-15">
                                                    <?php echo e($purchase->vendor_product->product->model); ?> -
                                                    <?php echo e($purchase->vendor_product->product->year); ?>

                                                </a>
                                            </h4>
                                            <div class="text-muted">
                                                <span class="text-dark">Manufactered By -
                                                    <?php echo e($purchase->vendor_product->product->make); ?></span> &nbsp;
                                                <span class="text-dark">Part Number -
                                                    <?php echo e($purchase->vendor_product->product->part_number); ?></span>
                                                <br>
                                                <?php echo e($purchase->vendor_product->description); ?>

                                                Quantity : <?php echo e($purchase->qty); ?>

                                            </div>
                                            <div class="text-primary d-flex mt-2 align-items-center">
                                                <?php
                                                    $totalAmount = $purchase->vendor_product->commercial_price * $purchase->qty;
                                                ?>
                                                Total :
                                                <h3 class="col-md-6 my-0 p-0 mx-2">
                                                    <?php echo e($totalAmount); ?><sup>$</sup>
                                                </h3>

                                                <?php if($purchase->status == 1): ?>
                                                    <button class="btn btn-danger ml-auto"
                                                        data-cancel="<?php echo e(route('vendor.purchase.cancel', ['id' => $purchase->id])); ?>"
                                                        type="button">Cancel</button>
                                                    <button class="btn btn-primary ml-1"
                                                        data-redirect-to="<?php echo e(route('vendor.order.invoice', ['id' => $purchase->id])); ?>"
                                                        type="button">Pay
                                                        <?php echo e($totalAmount); ?><sup>$</sup></button>
                                                <?php else: ?>
                                                    <button class="btn btn-primary ml-auto"
                                                        data-redirect-to="<?php echo e(route('vendor.order.track', ['access' => csrf_token() ,'identity' => $purchase->unique_id])); ?>"
                                                        type="button">Details
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div> <!-- row -->
                        <?php echo $__env->make('components.admin.pagination', ['paginator' => $purchases], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('components.vendor.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MORNING\Desktop\GlassInventory\resources\views/vendor/purchases/my.blade.php ENDPATH**/ ?>