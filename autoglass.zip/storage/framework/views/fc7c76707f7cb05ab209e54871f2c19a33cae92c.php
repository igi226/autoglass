<div class="modal" id="errorModal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content tx-size-sm">
            <div class="modal-body tx-center pd-y-20 pd-x-20"> <button aria-label="Close" class="close"
                    data-dismiss="modal" type="button"><span aria-hidden="true">×</span></button> <i
                    class="icon icon ion-ios-close-circle-outline tx-100 tx-danger lh-1 mg-t-20 d-inline-block"></i>
                <h4 class="tx-danger mg-b-20" id="errorHeading"></h4>
                <p class="mg-b-20 mg-x-20" id="errorMessage"></p>
                <button aria-label="Close" class="btn btn-danger pd-x-25"
                    data-dismiss="modal" type="button">Ok</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/q7pqffo8kaqr/public_html/autoglassb2b.com/resources/views/components/vendor/error.blade.php ENDPATH**/ ?>