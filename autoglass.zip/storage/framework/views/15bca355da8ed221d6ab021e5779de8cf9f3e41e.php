

<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-signin-wrapper">
        <div class="main-card-signin d-md-flex">
            <div class="p-5 w-100">
                <div class="main-signin-header">
                    <h2>Create an Account!</h2>
                    <h4>Register to Glass Inventory</h4>
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-solid-danger mb-3" role="alert">
                            <button aria-label="Close" class="close" data-dismiss="alert" type="button">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <strong>Error :<br> </strong>
                           <?php echo Session::get('error'); ?>

                        
                        </div>
                    <?php elseif(Session::has('success')): ?>
                        <div class="alert alert-solid-success mb-3" role="alert">
                            <button aria-label="Close" class="close" data-dismiss="alert" type="button">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>
                    
                   
                    <form action="<?php echo e(route('vendor.register')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group"> <label>Full Name</label> <input class="form-control"
                                placeholder="Enter your name" type="text" name="name" value="<?php echo e(old('name')); ?>" required> </div>
                        <div class="form-group"> <label>Email</label> <input class="form-control"
                                placeholder="Enter your email" type="email" name="email" value="<?php echo e(old('email')); ?>" required> </div>
                        <div class="form-group"> <label>Password</label> <input class="form-control"
                                placeholder="Enter your password" type="password" name="password" value="<?php echo e(old('password')); ?>" required> </div>
                        <div class="form-group"> <label>Confirm Password</label> <input class="form-control"
                                placeholder="Enter your confirm password" type="password" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" required> </div>
                                
                                <script src="https://www.google.com/recaptcha/api.js"></script>
                                <div class="g-recaptcha" data-sitekey="<?php echo e(env('GOOGLE_RECAPTCHA_KEY')); ?>" data-callback="correctCaptcha"></div>
                               <script>
                                var correctCaptcha = function(response) {
                                    
                                     document.getElementById('g-recaptcha-response').value = response;
                                };
                                </script>
                                 

                        <button class="btn btn-main-primary btn-block">Sign Up</button>
                    </form>
                    

                </div>
                <div class="main-signin-footer mg-t-5">
                    <p>Already have an account? <a href="<?php echo e(route('vendor.login')); ?>">Login</a></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/autoglassb2b/public_html/resources/views/vendor/auth/register.blade.php ENDPATH**/ ?>