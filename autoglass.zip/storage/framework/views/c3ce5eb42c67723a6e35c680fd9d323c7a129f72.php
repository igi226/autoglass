

<?php $__env->startSection('title', 'Market Place'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="main-content-breadcrumb"> <span>Vendor</span><span>Market Place</span>
                        <div class="main-content-title ml-auto mb-0">Market Place</div>
                    </div>
                    <div class="main-content-header container p-4 bg-white">
                        <div>
                            <h6 class="main-content-title tx-18 mg-b-5 mg-t-5">Advance Search</h6>
                        </div>
                        <form class="advance_search_form" method="GET">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="advance" value="1">
                            <div class="form-group">
                                <label class="main-content-label tx-11 tx-medium tx-gray-600">Year</label>

                                <input type="text" class="form-control" name="year">
                            </div>
                            <div class="form-group">
                                <label class="main-content-label tx-11 tx-medium tx-gray-600">Make</label>

                                <input type="text" class="form-control" name="make">
                            </div>
                            <div class="form-group">
                                <label class="main-content-label tx-11 tx-medium tx-gray-600">Model</label>

                                <input type="text" class="form-control" name="model">
                            </div>
                            <div class="form-group">
                                <label class="main-content-label tx-11 tx-medium tx-gray-600">Type</label>

                                <input type="text" class="form-control" name="type">
                            </div>
                            <div class="form-group">
                                <label class="main-content-label tx-11 tx-medium tx-gray-600">Part Number</label>

                                <input type="text" class="form-control" name="part_number">
                            </div>
                            <div class="form-group">
                                <label class="main-content-label tx-11 tx-medium tx-gray-600 d-hidden">
                                    Search
                                </label>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-search"></i>
                                    Search
                                </button>
                            </div>
                        </form>
                    </div>
                    <div class="main-content-body">
                        <div class="d-flex flex-column flex-md-row-reverse justify-content-between">
                            <div class="col-md-12 p-0 pr-md-3">
                                <div class="row row-sm row-cards row-deck">
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6">
                                            <div class="card mg-b-20 card-aside">
                                                <div class="card-body d-flex flex-column">
                                                    <h4>
                                                        <a href="#" class="text-dark tx-15">
                                                            <?php echo e($product->product->model); ?> - <?php echo e($product->product->year); ?>

                                                        </a>
                                                    </h4>
                                                    <div class="text-muted min-h-84">
                                                        <span class="text-dark">Manufactered By -
                                                            <?php echo e($product->product->make); ?></span> &nbsp;
                                                        <span class="text-dark">Part Number -
                                                            <?php echo e($product->product->part_number); ?></span>
                                                        <br>
                                                        <?php echo e($product->description); ?>

                                                    </div>
                                                    <div class="row py-2 align-items-center">
                                                        <h4 class="col-md-6 text-primary fw-light">
                                                            <?php echo e($product->commercial_price); ?><sup>$</sup>
                                                        </h4>
                                                        <div class="col-md-6 text-md-right">
                                                            <button
                                                                data-action="<?php echo e(route('vendor.order.request', ['id' => $product->id])); ?>"
                                                                class="btn btn-primary" data-target="#checkModal"
                                                                data-toggle="modal" type="button">
                                                                Check Availability
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                            <!-- row -->

                        </div>
                        <?php echo $__env->make('components.admin.pagination', ['paginator' => $products], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('components.vendor.check', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/q7pqffo8kaqr/public_html/autoglassb2b.com/resources/views/vendor/market/index.blade.php ENDPATH**/ ?>