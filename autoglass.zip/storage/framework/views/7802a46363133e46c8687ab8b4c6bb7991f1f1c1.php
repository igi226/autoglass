<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(route('admin.index')); ?>"><?php echo e(env('APP_NAME')); ?></a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(route('admin.index')); ?>"><?php echo e(env('APP_NAME')[0]); ?></a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Dashboard</li>
            <li><a class="nav-link" href="<?php echo e(route('admin.index')); ?>"><i class="fas fa-fire"></i>
                    <span>Dashboard</span></a></li>
            <li class="menu-header">Inventory</li>
            <li><a class="nav-link" href="<?php echo e(route('admin.product.index')); ?>"><i class="fas fa-dolly-flatbed"></i>
                    <span>Part Inventory</span></a></li>
            <li><a class="nav-link" href="<?php echo e(route('admin.product.request')); ?>"><i class="fas fa-upload"></i>
                    <span>Product Requests</span></a></li>
            <li class="menu-header">User management</li>
            <li><a class="nav-link" href="<?php echo e(route('admin.user.index')); ?>"><i class="fas fa-user"></i>
                    <span>User Management</span></a></li>
            <li><a class="nav-link" href="<?php echo e(route('admin.user.requests')); ?>"><i class="fas fa-user-check"></i>
                    <span>Registration Requests</span></a></li>
            
        </ul>

        <div class="mt-4 mb-4 p-3 hide-sidebar-mini">
            <a href="<?php echo e(route('admin.password.change')); ?>" class="btn btn-primary btn-lg btn-block btn-icon-split">
                <i class="fas fa-cog"></i>Change Password
            </a>
        </div>
    </aside>
</div>
<?php /**PATH /home/devhigiapp/public_html/glassinventory/resources/views/components/admin/sidebar.blade.php ENDPATH**/ ?>