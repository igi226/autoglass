

<?php $__env->startSection('title', 'Track Your Order'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="main-content-breadcrumb"> <span>Vendor</span><span>Track Order</span>
                        <div class="main-content-title ml-auto mb-0">Track Order</div>
                    </div>
                    <div class="main-content-header container p-4 bg-white">
                        <div>
                            <h6 class="main-content-title tx-18 mg-b-5 mg-t-5">Track your Order</h6>
                            <p class="main-content-text tx-13 mg-b-5">Track the current Status of your Order from here.</p>
                        </div>
                    </div>
                    <?php
                        $order_statuses = $order->order_statuses;
                        $last_status = $order
                            ->order_statuses()
                            ->orderBy('id', 'desc')
                            ->first();
                        $default_status = ['ordered', 'Dispatched', 'Delivered'];
                        $placeholder = $order_statuses->count();
                    ?>
                    <div class="main-content-header container p-4 bg-white">
                        <div class="row w-100">
                            <div class="w-100 pt45 pb20">
                                <div class="row justify-content-between">
                                    <?php $__currentLoopData = $order_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($key > 2): ?>
                                            <?php break; ?>
                                        <?php endif; ?>
                                    <div class="order-tracking completed">
                                        <span class="is-complete"></span>
                                        <p><?php echo e($order_status->status); ?><br><span><?php echo e($order_status->created_at->format('H:i, d F')); ?></span>
                                        </p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($placeholder < 3): ?>
                                    <?php $__currentLoopData = array_slice($default_status, $placeholder); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="order-tracking">
                                            <span class="is-complete"></span>
                                            <p><?php echo e($order_status); ?><br><span>Pending</span></p>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="main-content-body d-flex flex-column">
                    <div class="row row-sm row-cards row-deck">
                        <div class="col-lg-4">
                            <div class="card bd-0 mg-b-20">
                                <div class="card-body text-success">
                                    <div class="main-error-wrapper"> <i class="si si-check mg-b-20 tx-50"></i>
                                        <h4 class="mg-b-20"><?php echo e($last_status->status); ?></h4>
                                        <p class="text-muted">
                                            <?php echo e($last_status->comment); ?>

                                            <br>
                                            Updated At : <?php echo e($last_status->created_at->format('H:i, d F')); ?>

                                        </p>
                                        <a class="btn btn-success btn-sm btn-rounded"
                                            href="<?php echo e(route('vendor.order.invoice', ['id' => $order->id])); ?>">Click to
                                            view
                                            Invoice</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="card mg-b-20 card-aside">
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table mg-b-0 text-md-nowrap">
                                            <thead>
                                                <tr>
                                                    <th>Date and Time</th>
                                                    <th>Status</th>
                                                    <th>Message</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $order_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($order_status->created_at->format('d F, H:i')); ?></td>
                                                        <td><?php echo e($order_status->status); ?></td>
                                                        <td><?php echo e($order_status->comment); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if($order->status == 6): ?>
    <?php echo $__env->make('components.vendor.confirmation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    <?php if($order->status == 6): ?>
        $('#confirmModal').modal('show');
        $('.next-step').on('click', function() {
            $('#prevStep').hide();
            $('#nextStep').show();
        })
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/autoglassb2b/public_html/resources/views/vendor/orders/details.blade.php ENDPATH**/ ?>