

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content px-0">
        <div class="main-content-header container p-4 bg-white">
            <div>
                <h6 class="main-content-title tx-18 mg-b-5 mg-t-5">Welcome to <?php echo e(env('APP_NAME')); ?></h6>
                <p class="main-content-text tx-13 mg-b-5">Hi, welcome back! Here's your details of Sales and Orders.</p>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card mg-b-20">
                                <div class="card-body">
                                    <label class="main-content-label">Total Sale</label>
                                    <h1 class="card-title">$<?php echo e($totalEarning); ?></h1><small class="main-content-text">
                                        *Reports are generated after every Orders and Purchase
                                    </small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card mg-b-20">
                                <div class="card-body p-4">
                                    <div> <label class="main-content-label">Quick Ratio Of Sales</label>
                                        <h5 class="mg-b-5"><?php echo e($orderCount); ?>:<?php echo e($saleCount); ?></h5>
                                        <?php
                                            if ($saleCount != 0 && $orderCount != 0) {
                                                $percent = ($saleCount / $orderCount) * 100;
                                            } else {
                                                $percent = 0;
                                            }
                                        ?>
                                        <div class="progress ht-10 mg-b-5">
                                            <div aria-valuemax="<?php echo e($orderCount); ?>" aria-valuemin="0"
                                                aria-valuenow="<?php echo e($saleCount); ?>" class="progress-bar bg-pink"
                                                role="progressbar" style="width: <?php echo e($percent); ?>%;"></div>
                                        </div><span class="tx-12 tx-gray-500">Quick Ratio Sales: 1.0 or higher</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="card p-4">
                                <div class="card-title my-0">Order and Sales in <?php echo e(now()->year); ?></div>
                                <p class="my-1">A Representation of Order and Sales.</p>
                                <div class="card-body w-100 sales-bar" id="salesbar">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card--events card">
                        <div class="">
                            <div class="list-group">
                                <label class="main-content-label p-3">Recent Orders</label>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list-group-item">
                                        <div class="event-indicator bg-info"></div><label><?php echo e($order->created_at->format('d, F')); ?></label>
                                        <h6><?php echo e($order->unique_id); ?></h6>
                                        <p class="mb-0">
                                            Product : <?php echo e($order->vendor_product->product->part_number); ?> &nbsp;
                                            Quantity : <?php echo e($order->qty); ?>

                                        </p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('vendors/assets/plugins/flot/jquery.flot.js')); ?>"></script>
    <script src="<?php echo e(route('vendor.charts')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/autoglassb2b/public_html/resources/views/vendor/index.blade.php ENDPATH**/ ?>