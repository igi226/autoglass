<div id="notification">
    <img src="<?php echo e(asset('vendors/assets/img/users/user.png')); ?>" alt="" class="avatar">
    <p class="notification-message"></p>
    <small class="notification-timestamp"></small>
</div>
<?php /**PATH /home/autoglassb2b/public_html/resources/views/components/notification.blade.php ENDPATH**/ ?>