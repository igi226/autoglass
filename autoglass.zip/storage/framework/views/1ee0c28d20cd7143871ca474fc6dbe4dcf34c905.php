<?php
$user = get_user_details();
$newNotification = $user
    ->notifications()
    ->where('status', 0)
    ->get()
    ->count();
?>
<div class="main-dropdown-header mg-b-20 d-sm-none"> <a class="main-header-arrow" href=""><i
            class="icon ion-md-arrow-back"></i></a> </div>
<div class="p-3 border-bottom">
    <h6 class="main-notification-title">Notifications</h6>
    <?php if($newNotification): ?>
        <p class="main-notification-text mb-0">You have <?php echo e($newNotification); ?> unread notification</p>
    <?php endif; ?>
</div>
<div class="main-notification-list">
    <?php
        $notifications = $user
            ->notifications()
            ->orderBy('status', 'desc')
            ->limit(10)
            ->get();
    ?>
    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="media <?php if($notification->status == 0): ?> new <?php endif; ?>" data-redirect-to="<?php echo e($notification->url); ?>">
            <div class="main-img-user"><img alt="" src="<?php echo e(asset('vendors')); ?>/assets/img/users/user.png">
            </div>
            <div class="media-body">
                <p class="<?php if($notification->status == 0): ?> text-dark <?php endif; ?>">
                    <?php echo e($notification->message); ?>

                </p>
                <span>
                    <?php echo e($notification->created_at->format('d F, H:i')); ?>

                </span>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\MORNING\Desktop\GlassInventory\resources\views/partials/vendor/notification.blade.php ENDPATH**/ ?>