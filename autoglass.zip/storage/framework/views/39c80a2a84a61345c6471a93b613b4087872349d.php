

<?php $__env->startSection('title', 'My profile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content main-content-profile">
        <div class="container">
            <!-- breadcrumb -->
            <div class="main-content-breadcrumb"> <span>Vendor</span><span>My Profile</span>
                <div class="main-content-title ml-auto mb-0">My Profile</div>
            </div> <!-- /breadcrumb -->
            <!-- row -->
            <div class="row row-sm">
                <!-- Col -->
                <div class="col-lg-4">
                    <div class="card mg-b-20">
                        <div class="card-body">
                            <div class="pl-0">
                                <div class="main-profile-overview">
                                    <form action="<?php echo e(route('vendor.avatar.update')); ?>" method="post" id="avatar_form">
                                        <?php echo csrf_field(); ?>
                                        <input type="file" name="file" id="avatar_file" class="d-none" accept=".png,.jpeg,.jpg">
                                        <input type="hidden" name="old_file" value="<?php echo e($user->avatar); ?>">
                                    </form>
                                    <div class="main-img-user profile-user">
                                        <?php if($user->avatar): ?>
                                            <img alt="Profile Image"
                                                src="<?php echo e(asset('storage/avatars')); ?>/<?php echo e($user->avatar); ?>" id="profile_image">
                                        <?php else: ?>
                                            <img alt="Profile Image" src="<?php echo e(asset('vendors/assets/img/users/user.png')); ?>" id="profile_image">
                                        <?php endif; ?>
                                        <label class="fas fa-camera profile-edit text-primary" for="avatar_file"></label>
                                    </div>
                                    <div class="d-flex justify-content-between mg-b-20">
                                        <div>
                                            <h5 class="main-profile-name"><?php echo e($user->name); ?></h5>
                                            <p class="main-profile-name-text"><?php echo e($user->company); ?></p>
                                        </div>
                                    </div>
                                </div><!-- main-profile-overview -->
                            </div>
                        </div>
                    </div>
                    <div class="card mg-b-20">
                        <div class="card-body">
                            <div class="main-content-label tx-13 mg-b-25"> Conatct </div>
                            <div class="main-profile-contact-list">
                                <div class="media">
                                    <div class="media-icon bg-primary-transparent text-primary"> <i
                                            class="icon ion-md-phone-portrait"></i> </div>
                                    <div class="media-body"> <span>Mobile</span>
                                        <div>
                                            <?php echo e($user->phone); ?>

                                            <?php if(!$user->phone): ?>
                                                Not Available
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="media">
                                    <div class="media-icon bg-success-transparent text-success"> <i
                                            class="icon ion-md-mail"></i> </div>
                                    <div class="media-body"> <span>E-mail</span>
                                        <div>
                                            <?php echo e($user->email); ?>

                                            <?php if(!$user->email): ?>
                                                Not Available
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="media">
                                    <div class="media-icon bg-info-transparent text-info"> <i
                                            class="icon ion-md-locate"></i> </div>
                                    <div class="media-body"> <span>Current Address</span>
                                        <div>
                                            <?php echo e($user->address); ?>

                                            <?php if(!$user->address): ?>
                                                Not Available
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- main-profile-contact-list -->
                        </div>
                    </div>
                </div> <!-- /Col -->
                <!-- Col -->
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-body">
                            <div class="mb-4 main-content-label">Personal Information</div>
                            <form class="form-horizontal" action="<?php echo e(route('vendor.profile.update')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="mb-4 main-content-label">Name</div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-md-3"> <label class="form-label">Name</label> </div>
                                        <div class="col-md-9"> <input type="text" class="form-control"
                                                placeholder="Full Name" value="<?php echo e($user->name); ?>" name="name" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-4 main-content-label">Contact Info</div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-md-3"> <label class="form-label">Email<i>(required)</i></label>
                                        </div>
                                        <div class="col-md-9"> <input type="text" class="form-control"
                                                placeholder="Email" value="<?php echo e($user->email); ?>" name="email" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-md-3"> <label class="form-label">Mobile No.</label> </div>
                                        <div class="col-md-9"> <input type="tel" class="form-control"
                                                placeholder="Contact No." value="<?php echo e($user->phone); ?>" name="phone">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-md-3"> <label class="form-label">Address</label> </div>
                                        <div class="col-md-9">
                                            <textarea class="form-control" name="address" rows="2" placeholder="Address" name="address"><?php echo e($user->address); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-4 main-content-label">Company Information</div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-md-3"> <label class="form-label">Company</label> </div>
                                        <div class="col-md-9"> <input type="text" class="form-control"
                                                placeholder="Company" value="<?php echo e($user->company); ?>" name="company"> </div>
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-md-3"> <label class="form-label">Owner</label> </div>
                                        <div class="col-md-9"> <input type="text" class="form-control"
                                                placeholder="Owner Of the Company" value="<?php echo e($user->owner); ?>"
                                                name="owner"> </div>
                                    </div>
                                </div>
                                <div class="mb-4 main-content-label">Tax Information</div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-md-3"> <label class="form-label">Tax Identification Number(TIN)</label> </div>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" name="tax_id"
                                                placeholder="Tax Id" value="<?php echo e($user->tax_id); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group"> <button type="submit"
                                        class="btn btn-primary waves-effect waves-light">Update Profile</button> </div>
                            </form>
                        </div>

                    </div>
                </div> <!-- /Col -->
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('vendors')); ?>/assets/js/profile.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MORNING\Desktop\GlassInventory\resources\views/vendor/profile.blade.php ENDPATH**/ ?>