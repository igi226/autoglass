

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-signin-wrapper">
        <div class="main-card-signin d-md-flex">
            <div class="p-5 w-100">
                <div class="main-signin-header">
                    <h2>Welcome back!</h2>
                    <h4>Please Sign in to continue</h4>
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-solid-danger mb-3" role="alert">
                            <button aria-label="Close" class="close" data-dismiss="alert" type="button">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <strong>Error : </strong><?php echo e(Session::get('error')); ?>

                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('vendor.login')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group"> <label>Email</label> <input class="form-control"
                                placeholder="Enter your email" type="email" name="email" required> </div>
                        <div class="form-group"> <label>Password</label> <input class="form-control"
                                placeholder="Enter your password" type="password" name="password" required> </div><button
                            class="btn btn-main-primary btn-block">Sign In</button>
                    </form>
                </div>
                <div class="main-signin-footer mg-t-5">
                    <p><a href="">Forgot password?</a></p>
                    <p>Don't have an account? <a href="<?php echo e(route('vendor.register')); ?>">Create an Account</a></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MORNING\Desktop\GlassInventory\resources\views/vendor/auth/login.blade.php ENDPATH**/ ?>