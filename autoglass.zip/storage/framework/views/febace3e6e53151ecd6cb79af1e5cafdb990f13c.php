<div class="main-header shadow-none">
    <div class="container">
        <?php
            $user = get_user_details();
        ?>
        <!--logo-->
        <div class="main-header-left"> <a class="main-header-menu-icon d-lg-none" href=""
                id="mainNavShow"><span></span></a>
            <a class="main-logo text-white d-none d-md-block" href="<?php echo e(route('vendor.index')); ?>">
                Glass Inventory
            </a>
        </div>
        <!--/logo-->
        <div class="main-header-center">
            <form method="GET" action="<?php echo e(route('vendor.market.index')); ?>" class="search-element">
                <input class="form-control" placeholder="Search" type="search" name="search">
                <button class="btn" type="submit">
                    <i class="fas fa-search"></i>
                </button>
            </form>
            <a href="#" data-toggle="search" class="nav-link nav-link-lg d-md-none navsearch">
                <button class="btn">
                    <i class="ti-search"></i>
                </button>
            </a>
        </div>
        <div class="main-header-right">
            <?php
                $newNotification = $user
                    ->notifications()
                    ->where('status', 0)
                    ->get()
                    ->count();
            ?>
            <div class="dropdown main-header-notification">
                <a class="<?php if($newNotification): ?> new <?php endif; ?>" href="javascript:void"
                    data-sync="<?php echo e(route('vendor.notification.mark')); ?>">
                    <i class="ti-bell"></i>
                </a>
                <div class="dropdown-menu notification-container">
                    <div class="main-dropdown-header mg-b-20 d-sm-none"> <a class="main-header-arrow" href=""><i
                                class="icon ion-md-arrow-back"></i></a> </div>
                    <div class="p-3 border-bottom">
                        <h6 class="main-notification-title">Notifications</h6>
                        <p class="main-notification-text mb-0">
                            <?php if($newNotification): ?>
                                You have <?php echo e($newNotification); ?> unread notification
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="main-notification-list">
                        <?php
                            $notifications = $user
                                ->notifications()
                                ->orderBy('id', 'desc')
                                ->orderBy('status', 'desc')
                                ->limit(6)
                                ->get();
                        ?>
                        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media <?php if($notification->status == 0): ?> new <?php endif; ?>"
                                data-redirect-to="<?php echo e($notification->url); ?>">
                                <div class="main-img-user"><img alt=""
                                        src="<?php echo e(asset('vendors')); ?>/assets/img/users/user.png">
                                </div>
                                <div class="media-body">
                                    <p class="<?php if($notification->status == 0): ?> text-dark <?php endif; ?>">
                                        <?php echo $notification->message; ?>

                                    </p>
                                    <span>
                                        <?php echo e($notification->created_at->format('d F, H:i')); ?>

                                    </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="dropdown-footer"> <a href="<?php echo e(route('vendor.notifications')); ?>">View All
                            Notifications</a> </div>
                </div>
            </div>
            <div class="dropdown main-profile-menu">
                <a class="main-img-user" href="">
                    <?php if($user->avatar == null): ?>
                        <img alt="Avatar" src="<?php echo e(asset('vendors')); ?>/assets/img/users/user.png">
                    <?php else: ?>
                        <img alt="Avatar" src="<?php echo e(asset('storage/avatars')); ?>/<?php echo e($user->avatar); ?>">
                    <?php endif; ?>
                </a>
                <div class="dropdown-menu">
                    <div class="main-dropdown-header d-sm-none"> <a class="main-header-arrow" href=""><i
                                class="icon ion-md-arrow-back"></i></a> </div>
                    <div class="main-header-profile">
                        <div class="main-img-user">
                            <?php if($user->avatar == null): ?>
                                <img alt="Avatar" src="<?php echo e(asset('vendors')); ?>/assets/img/users/user.png">
                            <?php else: ?>
                                <img alt="Avatar" src="<?php echo e(asset('storage/avatars')); ?>/<?php echo e($user->avatar); ?>">
                            <?php endif; ?>
                        </div>
                        <h6><?php echo e($user->name); ?></h6>
                        <p><?php echo e($user->company); ?></p>
                    </div>
                    <a class="dropdown-item" href="<?php echo e(route('vendor.profile')); ?>">
                        <i class="si si-user"></i> My Profile
                    </a>
                    <a class="dropdown-item" href="<?php echo e(route('vendor.mypurchase')); ?>">
                        <i class="ti-shopping-cart"></i> My Puchases
                    </a>
                    <a class="dropdown-item" href="#" id="createReportContext">
                        <i class="ti-flag"></i> Report an Issue
                    </a>
                    <a class="dropdown-item" href="<?php echo e(route('vendor.logout')); ?>">
                        <i class="si si-power"></i> Sign Out
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="sticky-wrapper" class="sticky-wrapper" style="height: 3710.41px;">
    <div class="main-navbar" style="">
        <div class="container">
            <ul class="nav">
                <li class="nav-label">Main Menu</li>
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('vendor.index')); ?>"><i
                            class="ti ti-desktop"></i>Dashboard</a> </li>
                <li class="nav-item"> <a class="nav-link with-sub" href="">
                        <i class="ti-package"></i>Products</a>
                    <ul class="nav-sub">
                        <li class="nav-sub-item"> <a class="nav-sub-link"
                                href="<?php echo e(route('vendor.product.index')); ?>">Product Inventory</a> </li>
                        <li class="nav-sub-item"> <a class="nav-sub-link"
                                href="<?php echo e(route('vendor.product.myproduct')); ?>">Active Products</a> </li>
                        <li class="nav-sub-item"> <a class="nav-sub-link"
                                href="<?php echo e(route('vendor.product.pending')); ?>">Pending Products</a> </li>
                        <li class="nav-sub-item"> <a class="nav-sub-link"
                                href="<?php echo e(route('vendor.product.request')); ?>">Product Requests</a> </li>
                    </ul>
                </li>
                <li class="nav-item"> <a class="nav-link with-sub" href="">
                        <i class="ti-notepad"></i>Orders</a>
                    <ul class="nav-sub">
                        <li class="nav-sub-item"> <a class="nav-sub-link"
                                href="<?php echo e(route('vendor.orders.requests')); ?>">Order Requests</a> </li>
                        <li class="nav-sub-item"> <a class="nav-sub-link"
                                href="<?php echo e(route('vendor.order.refunds')); ?>">Refund Requests</a>
                        </li>
                        <li class="nav-sub-item"> <a class="nav-sub-link"
                                href="<?php echo e(route('vendor.order.index')); ?>">Order History</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('vendor.market.index')); ?>"><i
                            class="ti ti-shopping-cart"></i>Market Place</a> </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH /home/devhigiapp/public_html/glassinventory/resources/views/components/vendor/header.blade.php ENDPATH**/ ?>