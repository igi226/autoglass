

<?php $__env->startSection('title', $page['heading']); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="main-content-body d-flex flex-column">
                        <!-- breadcrumb -->
                        <div class="main-content-breadcrumb"> <span>Vendor</span> <span>Products</span>
                            <span><?php echo e($page['heading']); ?></span>
                            <div class="main-content-title mb-0 ml-auto"><?php echo e($page['heading']); ?></div>
                        </div> <!-- /breadcrumb -->
                        <?php
                            $error_products = get_error_products();
                        ?>
                        <?php if($error_products): ?>
                            <div class="alert alert-solid-danger" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <i class="fa fa-exclamation-circle"></i>

                                Looks Like You've <b><?php echo e($error_products); ?></b> Products without a Valid Retail and Commercial Price! Please Update them with proper pricing to List Them into Market Place.
                            </div>
                        <?php endif; ?>
                        <div class="card">
                            <div class="card-body">
                                <div class="main-content-label mg-b-5"><?php echo e($page['heading']); ?></div>
                                <p class="mg-b-20"><?php echo e($page['subheading']); ?></p>
                                <form method="GET" class="col-md-4 col-6 mb-3 p-0 float-right">
                                    <div class="input-group">
                                        <input class="form-control" name="search" placeholder="Search" type="text">
                                        <span class="input-group-btn">
                                            <button class="btn btn-primary" type="submit">
                                                <span class="input-group-btn">
                                                    <i class="fa fa-search"></i>
                                                </span>
                                            </button>
                                        </span>
                                    </div>
                                </form>
                                <div class="table-responsive">
                                    <table id="example-1" class="table table-striped table-bordered nowrap text-md-nowrap">
                                        <thead>
                                            <tr>
                                                <th class="border-bottom-0">
                                                    #
                                                </th>
                                                <th class="border-bottom-0">Year</th>
                                                <th class="border-bottom-0">Make</th>
                                                <th class="border-bottom-0">Model</th>
                                                <th class="border-bottom-0">Type</th>
                                                <th class="border-bottom-0">Part Number</th>
                                                <th class="border-bottom-0">Brand</th>
                                                <th class="border-bottom-0">Description</th>
                                                <th class="border-bottom-0">Quantity</th>
                                                <th class="border-bottom-0">Commercial Price</th>
                                                <th class="border-bottom-0">Retail Price</th>
                                                <th class="border-bottom-0">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $i = generate_count($products);
                                            ?>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="border-bottom-0">
                                                        <?php echo e($i++); ?>

                                                    </td>
                                                    <td><?php echo e($product->product->year); ?></td>
                                                    <td><?php echo e($product->product->make); ?></td>
                                                    <td><?php echo e($product->product->model); ?></td>
                                                    <td><?php echo e($product->product->type); ?></td>
                                                    <td><?php echo e($product->product->part_number); ?></td>
                                                    <td><?php echo e($product->product->brand); ?></td>
                                                    <td><?php echo e($product->description); ?></td>
                                                    <td><?php echo e($product->qty); ?></td>
                                                    <td><?php echo e($product->commercial_price); ?> $</td>
                                                    <td><?php echo e($product->retail_price); ?> $</td>
                                                    <td>
                                                        <a href="<?php echo e(route('vendor.product.delete', ['id' => $product->id])); ?>"
                                                            class="text-danger mx-1 fas fa-trash"></a>
                                                        <a href="<?php echo e(route('vendor.product.edit', ['id' => $product->id])); ?>"
                                                            class="text-info mx-1 fas fa-edit"></a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php echo $__env->make('components.admin.pagination', ['paginator' => $products], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <!--/div-->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MORNING\Desktop\GlassInventory\resources\views/vendor/products/myproduct.blade.php ENDPATH**/ ?>