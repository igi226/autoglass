

<?php $__env->startSection('title', 'Refund Requests'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="main-content-body d-flex flex-column">
                        <!-- breadcrumb -->
                        <div class="main-content-breadcrumb"> <span>Vendor</span> <span>Orders</span>
                            <span>Refund Requests</span>
                            <div class="main-content-title mb-0 ml-auto">Refund Requests</div>
                        </div> <!-- /breadcrumb -->

                        <div class="card">
                            <div class="card-body">
                                <div class="main-content-label mg-b-5">Refund Requests</div>
                                <p class="mg-b-20">Refund Requests for Orders</p>
                                <div class="table-responsive">
                                    <table id="example-1" class="table table-striped table-bordered nowrap text-md-nowrap">
                                        <thead>
                                            <tr>
                                                <th class="border-bottom-0">
                                                    #
                                                </th>
                                                <th class="border-bottom-0">Relevant Image</th>
                                                <th>Customer</th>
                                                <th class="border-bottom-0">Order Reference</th>
                                                <th class="border-bottom-0">Product</th>
                                                <th class="border-bottom-0">Quantity</th>
                                                <th class="border-bottom-0">Cause</th>
                                                <th class="border-bottom-0">Current Status</th>
                                                <th class="border-bottom-0">Date and Time</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $i = generate_count($refunds);
                                            ?>
                                            <?php $__currentLoopData = $refunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i++); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(asset('storage')); ?>/refunds/<?php echo e($refund->image); ?>"
                                                            target="_blank">
                                                            <img class="w-100"
                                                                src="<?php echo e(asset('storage')); ?>/refunds/<?php echo e($refund->image); ?>"
                                                                alt="">
                                                        </a>
                                                    </td>
                                                    <td><?php echo e($refund->order->user->name); ?></td>
                                                    <td><?php echo e($refund->order->unique_id); ?></td>
                                                    <td><?php echo e($refund->order->vendor_product->product->part_description); ?>

                                                    </td>
                                                    <td><?php echo e($refund->order->qty); ?></td>
                                                    <td><?php echo e($refund->issue); ?></td>
                                                    <td>
                                                        <a href="javascript:void"
                                                            data-action="<?php echo e(route('vendor.refund.action', ['id' => $refund->order->id])); ?>"
                                                            data-placement="left" data-toggle="tooltip"
                                                            title="Click to Update!"
                                                            class="badge order_update badge-info py-1 px-2">
                                                            <?php echo e(get_order_status($refund->order->status)); ?>

                                                        </a>
                                                    </td>
                                                    <td><?php echo e($refund->created_at->format('d F, Y')); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php echo $__env->make('components.admin.pagination', ['paginator' => $refunds], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <!--/div-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('components.vendor.refund', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('.order_update').on('click', (e) => {
            e.preventDefault();
            $('#updateForm').attr('action', e.target.dataset.action);
            $('#updateModal').modal('show');
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MORNING\Projects\GlassInventory\resources\views/vendor/orders/refunds.blade.php ENDPATH**/ ?>