

<?php $__env->startSection('title', 'Part Inventory'); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admins')); ?>/assets/modules/datatables/datatables.min.css">
    <link rel="stylesheet"
        href="<?php echo e(asset('admins')); ?>/assets/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet"
        href="<?php echo e(asset('admins')); ?>/assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content" style="min-height: 702px;">
        <section class="section">
            <div class="section-header">
                <h1>Product Requests</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="#">Admin</a></div>
                    <div class="breadcrumb-item">Part Invenory</div>
                </div>
            </div>

            <div class="section-body">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="row card-body">

                                <div class="col-6">
                                    <a href="<?php echo e(route('admin.product.approve.all')); ?>" class="btn btn-info">
                                        Approve All <i class="fa fa-check"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.product.decline.all')); ?>" type="button"
                                        class="btn btn-danger">
                                        Decline All <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="card-body">
                                <form class="form-inline float-right" method="GET">
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" placeholder="Search" name="search">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="submit">
                                                <i class="fa fa-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                                <div class="table-responsive">
                                    <div id="table-2_wrapper"
                                        class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                                        <table class="table table-striped dataTable no-footer" id="table-2" role="grid"
                                            aria-describedby="table-2_info">
                                            <thead>
                                                <tr role="row">
                                                    <th>#</th>
                                                    <th>Year</th>
                                                    <th>Make</th>
                                                    <th>Model</th>
                                                    <th>Type</th>
                                                    <th>Part Number</th>
                                                    <th>Brand</th>
                                                    <th>Cost</th>
                                                    <th>Approval Status</th>
                                                    <th>Created At</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $i = generate_count($products);
                                                ?>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr role="row">
                                                        <td class="sorting_1">
                                                            <?php echo e($i++); ?>

                                                        </td>
                                                        <td><?php echo e($product->year); ?></td>
                                                        <td><?php echo e($product->make); ?></td>
                                                        <td><?php echo e($product->model); ?></td>
                                                        <td><?php echo e($product->type); ?></td>
                                                        <td><?php echo e($product->part_number); ?></td>
                                                        <td><?php echo e($product->brand); ?></td>
                                                        <td><?php echo e($product->price); ?>$</td>
                                                        <td>
                                                            <?php if($product->approved == 0): ?>
                                                                <a href="javascript:void"
                                                                    class="badge badge-info">Pending</a>
                                                            <?php elseif($product->approved == 2): ?>
                                                                <a href="javascript:void"
                                                                    class="badge badge-danger">Declined</a>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($product->created_at->format('d F, Y')); ?></td>
                                                        <td class="text-nowrap">
                                                            <a href="<?php echo e(route('admin.product.decline', ['id' => $product->id])); ?>"
                                                                class="btn btn-sm btn-icon text-danger"><i
                                                                    class="fas fa-times-circle"></i></a>
                                                            <a href="<?php echo e(route('admin.product.approve', ['id' => $product->id])); ?>"
                                                                class="btn btn-icon btn-sm text-info"><i
                                                                    class="fas fa-check-circle"></i></a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <?php echo $__env->make('components.admin.pagination', ['paginator' => $products], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <?php echo $__env->make('components.admin.import', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('admins')); ?>/assets/modules/datatables/datatables.min.js"></script>
    <script src="<?php echo e(asset('admins')); ?>/assets/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js">
    </script>
    <script src="<?php echo e(asset('admins')); ?>/assets/modules/datatables/Select-1.2.4/js/dataTables.select.min.js"></script>
    <script src="<?php echo e(asset('admins')); ?>/assets/modules/jquery-ui/jquery-ui.min.js"></script>
    <script src="<?php echo e(asset('admins')); ?>/assets/modules/sweetalert/sweetalert.min.js"></script>

    <!-- Page Specific JS File -->
    <script src="<?php echo e(asset('admins')); ?>/assets/js/page/product.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/autoglassb2b/public_html/resources/views/admin/products/request.blade.php ENDPATH**/ ?>