<?php $__env->startSection('title', 'Forgot Password'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-signin-wrapper">
        <div class="main-card-signin d-md-flex">
            <div class="p-5 w-100">
                <div class="main-signin-header">
                    <h2>Forgot Password!</h2>
                    <h4>Please enter your email to continue</h4>
                    <?php if(Session::has('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('message')); ?>

                            </div> 
                            <?php endif; ?>
                             <?php if(Session::has('message1')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('message1')); ?>

                            </div> 
                            <?php endif; ?>
                            <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(Session::get('error')); ?>

                            </div> 
                            <?php endif; ?>
    
                            
                           
             
                            <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                   
                    
                    <form name="forgot-password" id="forgot-password" method="POST" action="<?php echo e(route('vendor.forgot-password')); ?>">
                            <?php echo csrf_field(); ?> 
                            <div class="form-group">
                                <label>Email: <span class="text-danger">*</span></label>
                               
                                    <input type="email" class="form-control" name="email" id="email" value="<?php echo e(Request::old('email')); ?>" placeholder="" required>
                                                            
                           </div>
                         
                            
                            <button type="submit" class="btn btn-main-primary btn-block"><span>Send Email To Reset Password  </span></button>
                       
                         </form>
                </div>
               
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/autoglassb2b/public_html/resources/views/vendor/auth/forgot-password.blade.php ENDPATH**/ ?>