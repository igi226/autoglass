<div id="notification">
    <img src="<?php echo e(asset('vendors/assets/img/users/user.png')); ?>" alt="" class="avatar">
    <p class="notification-message"></p>
    <small class="notification-timestamp"></small>
</div>
<?php /**PATH /home/q7pqffo8kaqr/public_html/autoglassb2b.com/resources/views/components/notification.blade.php ENDPATH**/ ?>