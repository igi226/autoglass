

<?php $__env->startSection('title', 'Edit Product'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="main-content-body d-flex flex-column">
                        <!-- breadcrumb -->
                        <div class="main-content-breadcrumb"> <span>Vendor</span> <span>Products</span>
                            <span>Edit Product</span>
                            <div class="main-content-title mb-0 ml-auto">Edit Product</div>
                        </div> <!-- /breadcrumb -->

                        <div class="card mg-b-20">
                            <div class="card-body">
                                <div class="main-content-label mg-b-5">Edit Product </div>
                                <p class="mg-b-20">You Can Customize your Product From Here</p>
                                <form method="POST" class="row" action="<?php echo e(route('vendor.product.update', ['id' => $product->id])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-lg-6 mx-auto">
                                        <div class="form-group">
                                            <label class="form-label mb-2">Commercial Price</label>
                                            <input type="number" value="<?php echo e($product->commercial_price); ?>"
                                                class="form-control" name="commercial_price" placeholder="$" required>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label mb-2">Retail Price</label>
                                            <input type="number" value="<?php echo e($product->retail_price); ?>"
                                                class="form-control" name="retail_price" placeholder="$" required>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label mb-2">Quantity in Stock</label>
                                            <input type="number" value="<?php echo e($product->qty); ?>" class="form-control"
                                                name="qty" placeholder="0" required>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label mb-2">Description</label>
                                            <textarea name="description" class="form-control"><?php echo e($product->description); ?></textarea>
                                        </div>
                                        <button class="btn btn-primary" type="submit">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!--/div-->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MORNING\Desktop\GlassInventory\resources\views/vendor/products/edit.blade.php ENDPATH**/ ?>