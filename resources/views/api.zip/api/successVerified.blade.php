<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Verified</title>
</head>
<body>
    <div class="container">
        <div class="text-center">
            <div class="m-5">
                <h6>Successfully Verified</h6>
            </div>
        </div>
    </div>
</body>
</html>